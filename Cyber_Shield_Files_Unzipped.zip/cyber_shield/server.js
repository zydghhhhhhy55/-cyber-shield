require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.VIRUSTOTAL_API_KEY;

app.use(express.json({ limit: "10kb" }));
app.use(express.static(path.join(__dirname, "public")));

const recentRequests = new Map();
const WINDOW_MS = 60 * 1000;
const MAX_REQUESTS = 10;

function rateLimit(req, res, next) {
  const key = req.ip || "unknown";
  const now = Date.now();
  const entry = recentRequests.get(key);
  if (!entry || now - entry.start > WINDOW_MS) {
    recentRequests.set(key, { start: now, count: 1 });
    return next();
  }
  if (entry.count >= MAX_REQUESTS) {
    return res.status(429).json({ error: "أجريت فحوصات كثيرة خلال وقت قصير. انتظر دقيقة ثم حاول مجددًا." });
  }
  entry.count += 1;
  next();
}

function validateUrl(value) {
  if (typeof value !== "string" || value.length > 2048) return null;
  try {
    const parsed = new URL(value.trim());
    if (!["http:", "https:"].includes(parsed.protocol)) return null;
    if (!parsed.hostname || !parsed.hostname.includes(".")) return null;
    return parsed.toString();
  } catch {
    return null;
  }
}

app.post("/api/scan", rateLimit, async (req, res) => {
  if (!API_KEY || API_KEY === "ضع_مفتاحك_هنا") {
    return res.status(503).json({
      error: "الفحص الحقيقي غير مفعّل بعد. أضف مفتاح VirusTotal في ملف .env على الخادم."
    });
  }

  const url = validateUrl(req.body && req.body.url);
  if (!url) {
    return res.status(400).json({ error: "أدخل رابطًا صحيحًا يبدأ بـ https:// أو http://." });
  }

  try {
    const body = new URLSearchParams({ url });
    const response = await fetch("https://www.virustotal.com/api/v3/urls", {
      method: "POST",
      headers: { "x-apikey": API_KEY, "Content-Type": "application/x-www-form-urlencoded" },
      body
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const status = response.status === 429
        ? "وصلت الخدمة إلى حد الطلبات المسموح. حاول لاحقًا."
        : "تعذّر إرسال الرابط إلى خدمة الفحص. تحقق من المفتاح أو حاول لاحقًا.";
      return res.status(response.status === 429 ? 429 : 502).json({ error: status });
    }
    const analysisId = data && data.data && data.data.id;
    if (!analysisId) return res.status(502).json({ error: "لم تُرجع خدمة الفحص نتيجة قابلة للقراءة." });
    return res.json({ analysisId });
  } catch {
    return res.status(502).json({ error: "تعذّر الاتصال بخدمة الفحص. تحقق من الإنترنت ثم حاول مجددًا." });
  }
});

app.get("/api/analysis/:id", rateLimit, async (req, res) => {
  if (!API_KEY || API_KEY === "ضع_مفتاحك_هنا") {
    return res.status(503).json({ error: "مفتاح الفحص غير مضبوط على الخادم." });
  }
  const id = req.params.id;
  if (!/^[A-Za-z0-9_-]{5,200}$/.test(id)) {
    return res.status(400).json({ error: "معرّف الفحص غير صحيح." });
  }

  try {
    const response = await fetch(`https://www.virustotal.com/api/v3/analyses/${encodeURIComponent(id)}`, {
      headers: { "x-apikey": API_KEY }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      return res.status(response.status === 429 ? 429 : 502).json({
        error: response.status === 429 ? "طلبات كثيرة إلى خدمة الفحص. انتظر قليلًا." : "تعذّر جلب نتيجة الفحص."
      });
    }
    const attributes = data && data.data && data.data.attributes;
    if (!attributes) return res.status(502).json({ error: "نتيجة الفحص غير مكتملة." });
    return res.json({
      status: attributes.status || "queued",
      stats: attributes.stats || null
    });
  } catch {
    return res.status(502).json({ error: "انقطع الاتصال بخدمة الفحص أثناء انتظار النتيجة." });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Cyber Shield يعمل على http://localhost:${PORT}`);
});