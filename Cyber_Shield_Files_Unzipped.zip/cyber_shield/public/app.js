const form = document.getElementById("scan-form");
const input = document.getElementById("url-input");
const clearButton = document.getElementById("clear-button");
const scanButton = document.getElementById("scan-button");
const result = document.getElementById("result");
const resultIcon = document.getElementById("result-icon");
const resultTitle = document.getElementById("result-title");
const resultDescription = document.getElementById("result-description");
const resultDetails = document.getElementById("result-details");
const resultFootnote = document.getElementById("result-footnote");

document.getElementById("year").textContent = new Date().getFullYear();

clearButton.addEventListener("click", () => {
  input.value = "";
  input.focus();
  result.hidden = true;
});

function showResult(type, icon, title, description, footnote = "", chips = []) {
  result.className = `result-card ${type}`;
  resultIcon.textContent = icon;
  resultTitle.textContent = title;
  resultDescription.textContent = description;
  resultFootnote.textContent = footnote;
  resultDetails.replaceChildren();
  chips.forEach(text => {
    const chip = document.createElement("span");
    chip.className = "stat-chip";
    chip.textContent = text;
    resultDetails.appendChild(chip);
  });
  result.hidden = false;
}

function validUrl(raw) {
  try {
    const url = new URL(raw.trim());
    return ["http:", "https:"].includes(url.protocol) && url.hostname.includes(".") ? url.toString() : null;
  } catch {
    return null;
  }
}

function classify(stats) {
  const malicious = Number(stats.malicious || 0);
  const suspicious = Number(stats.suspicious || 0);
  const harmless = Number(stats.harmless || 0);
  const undetected = Number(stats.undetected || 0);
  const chips = [
    `خطير: ${malicious}`,
    `مشبوه: ${suspicious}`,
    `لم يرصد ضررًا: ${harmless}`,
    `غير محسوم: ${undetected}`
  ];
  if (malicious > 0) {
    showResult("danger", "×", "🔴 الرابط خطير", "رصدت خدمة الفحص مؤشرات ضارة في هذا الرابط.", "لا تفتح الرابط ولا تُدخل فيه أي معلومات شخصية.", chips);
  } else if (suspicious > 0) {
    showResult("suspicious", "!", "🟡 الرابط مشبوه", "ظهرت مؤشرات تستدعي الحذر، حتى لو لم تُرصد برمجيات ضارة.", "الأفضل عدم فتحه ما لم تتأكد من مصدره.", chips);
  } else if (harmless + undetected > 0) {
    showResult("clean", "✓", "🟢 لم تُرصد مؤشرات خطيرة", "لم ترصد نتائج الفحص مؤشرات ضارة أو مشبوهة حاليًا.", "هذه النتيجة لا تضمن أن الرابط آمن 100٪؛ تعامل بحذر دائمًا.", chips);
  } else {
    showResult("suspicious", "?", "🟡 النتيجة غير حاسمة", "لم تتوفر بيانات كافية لإصدار حكم موثوق.", "لا تعتبر هذا الرابط آمنًا لمجرد عدم وجود نتيجة واضحة.", chips);
  }
}

async function readJson(response) {
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "حدث خطأ أثناء الفحص.");
  return data;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const url = validUrl(input.value);
  if (!url) {
    showResult("error", "!", "الرابط غير صحيح", "أدخل رابطًا كاملًا يبدأ بـ https:// أو http://.", "لم يتم فتح الرابط.");
    input.focus();
    return;
  }

  scanButton.disabled = true;
  scanButton.querySelector("span:first-child").textContent = "جارٍ إرسال الرابط...";
  showResult("", "…", "جارٍ فحص الرابط", "يتم إرسال الرابط إلى خدمة الفحص. قد يستغرق التحليل بعض الوقت.", "لا تغلق الصفحة حتى تظهر النتيجة.");

  try {
    const submitted = await readJson(await fetch("/api/scan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url })
    }));

    let analysis = null;
    for (let attempt = 0; attempt < 12; attempt++) {
      await new Promise(resolve => setTimeout(resolve, attempt === 0 ? 1500 : 2000));
      analysis = await readJson(await fetch(`/api/analysis/${encodeURIComponent(submitted.analysisId)}`));
      if (analysis.status === "completed" && analysis.stats) break;
      resultDescription.textContent = "لا يزال التحليل جاريًا…";
    }

    if (!analysis || analysis.status !== "completed" || !analysis.stats) {
      showResult("suspicious", "…", "الفحص لم يكتمل بعد", "لم تصل النتيجة النهائية خلال الوقت المحدد.", "أعد الفحص لاحقًا. لا تعتبر الرابط نظيفًا ما دامت النتيجة غير مكتملة.");
    } else {
      classify(analysis.stats);
    }
  } catch (error) {
    showResult("error", "!", "تعذّر إكمال الفحص", error.message || "حدث خطأ غير متوقع.", "لم يتم إصدار نتيجة أمان. لا تعتبر الرابط نظيفًا عند فشل الفحص.");
  } finally {
    scanButton.disabled = false;
    scanButton.querySelector("span:first-child").textContent = "افحص الرابط";
  }
});